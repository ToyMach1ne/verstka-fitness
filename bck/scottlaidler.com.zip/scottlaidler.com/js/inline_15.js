
var tw_2 = null;

jQuery(document).ready(function() {
	tw_2 = jQuery('.testimonials-widget-testimonials2').bxSlider({
		adaptiveHeight: true,
		auto: true,
		
		autoHover: true,
		controls: false,
		mode: 'fade',
		pager: false,
		pause: 5000,
		video: false,
		slideMargin: 2,
		slideWidth: 0
	});
});
