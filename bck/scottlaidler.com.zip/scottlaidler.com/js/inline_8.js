
            var myAjaxFTS = 'http://scottlaidler.com/wp-admin/admin-ajax.php';
        