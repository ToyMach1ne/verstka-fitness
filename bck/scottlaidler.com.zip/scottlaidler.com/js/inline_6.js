
/* <![CDATA[ */
var ftsAjax = {"ajaxurl":"http:\/\/scottlaidler.com\/wp-admin\/admin-ajax.php"};
var ftsAjax = {"ajaxurl":"http:\/\/scottlaidler.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
