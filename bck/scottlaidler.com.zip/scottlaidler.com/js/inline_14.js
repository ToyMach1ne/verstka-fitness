
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/scottlaidler.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","recaptchaEmpty":"Please verify that you are not a robot.","sending":"Sending ...","cached":"1"};
/* ]]> */
